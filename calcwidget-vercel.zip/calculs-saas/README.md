# CalcWidget — Guide de déploiement sur Vercel

## Structure du projet
```
calculs-saas/
├── public/
│   ├── index.html   ← Page principale (landing + builder)
│   └── widget.html  ← Widget embarquable (chargé en iframe)
└── vercel.json      ← Config Vercel
```

## Déploiement en 5 minutes (gratuit)

### Étape 1 — Créez un compte GitHub
Allez sur https://github.com et créez un compte gratuit.

### Étape 2 — Créez un dépôt
- Cliquez sur "New repository"
- Nommez-le `calcwidget`
- Laissez-le public
- Cliquez "Create repository"

### Étape 3 — Uploadez les fichiers
- Glissez-déposez les fichiers `index.html` et `widget.html` dans le dossier `public/`
- Uploadez aussi `vercel.json` à la racine
- Cliquez "Commit changes"

### Étape 4 — Connectez Vercel
- Allez sur https://vercel.com
- Cliquez "Sign up" → "Continue with GitHub"
- Cliquez "New Project" → sélectionnez votre dépôt `calcwidget`
- Cliquez "Deploy" (Vercel détecte tout automatiquement)

### Étape 5 — C'est en ligne !
Vercel vous donne une URL du type `calcwidget.vercel.app`.
Partagez-la, les widgets générés fonctionneront immédiatement.

## Personnalisation rapide

### Changer le nom du site
Dans `index.html`, cherchez `CalcWidget` et remplacez par votre nom.

### Changer la couleur par défaut
Dans `index.html`, cherchez `#534AB7` (violet) et remplacez par votre couleur.

### Ajouter Stripe (paiements)
1. Créez un compte sur https://stripe.com (gratuit)
2. Créez un lien de paiement pour votre plan Pro (19€/mois)
3. Remplacez les boutons "Choisir Pro" par votre lien Stripe

## Monétisation suggérée

| Plan | Prix | Ce que vous gagnez |
|------|------|-------------------|
| Gratuit | 0€ | Acquisition |
| Pro | 19€/mois | 50 clients = 950€/mois |
| Agence | 49€/mois | 20 agences = 980€/mois |

## Support
Pour toute question, ouvrez une issue sur GitHub.
